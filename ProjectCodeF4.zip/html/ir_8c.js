var ir_8c =
[
    [ "CALI", "ir_8c.html#ab74ead41992c9239683f11ad974592dd", null ],
    [ "ir_cal_hand", "ir_8c.html#abbee8ca7eb35f7134f81de6e95b5d661", null ],
    [ "ir_cal_ping", "ir_8c.html#a44a23deff904158e0d0848f14c2e1365", null ],
    [ "ir_cal_putty", "ir_8c.html#a06373ba6852969202f7a037f5e771bb0", null ],
    [ "ir_calibrate", "ir_8c.html#a81bd61c685d6a30ee1eb938f846fb117", null ],
    [ "ir_Handler", "ir_8c.html#a12a92b3df4f5cceead5f34af35830d00", null ],
    [ "ir_init", "ir_8c.html#a398213820d1862c262f45bb51a4bb934", null ],
    [ "ir_pulse", "ir_8c.html#ae0ef162e4d3980dd7af9f300f3fad1bc", null ],
    [ "ir_read", "ir_8c.html#add570a4af157525bec586eb9b6753ebf", null ],
    [ "ir_test", "ir_8c.html#a6c8c1c006d3a1411e4c751985587ed89", null ]
];